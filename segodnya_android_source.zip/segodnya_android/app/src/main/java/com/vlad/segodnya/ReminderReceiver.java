package com.vlad.segodnya;

import android.app.*;
import android.content.*;
import android.os.*;

public class ReminderReceiver extends BroadcastReceiver {
    public static void schedule(Context c,String text,long when){
        Intent i=new Intent(c,ReminderReceiver.class);i.putExtra("text",text);
        int id=(int)(System.currentTimeMillis()&0x7fffffff);
        PendingIntent pi=PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(a!=null)a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
    }
    @Override public void onReceive(Context c,Intent i){
        String ch="tasks";
        NotificationManager n=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)n.createNotificationChannel(new NotificationChannel(ch,"Задачи",NotificationManager.IMPORTANCE_DEFAULT));
        Intent open=new Intent(c,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("Сегодня").setContentText(i.getStringExtra("text")).setContentIntent(pi).setAutoCancel(true);
        n.notify((int)(System.currentTimeMillis()&0xfffffff),b.build());
    }
}
