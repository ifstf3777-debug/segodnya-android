package com.vlad.segodnya;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout list;
    private TextView counter;
    private final ArrayList<Task> tasks = new ArrayList<>();
    private android.content.SharedPreferences prefs;
    private final int MAX = 20;

    static class Task { String text; int state; Task(String t,int s){text=t;state=s;} }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.rgb(8,9,13));
        if(Build.VERSION.SDK_INT>=30) getWindow().setDecorFitsSystemWindows(false);
        else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        prefs=getSharedPreferences("today",MODE_PRIVATE);
        resetIfNewDay(); load(); build();
    }

    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable glass(float radius,int alpha){
        GradientDrawable g=new GradientDrawable(); g.setColor(Color.argb(alpha,255,255,255)); g.setCornerRadius(dp(radius)); g.setStroke(dp(1),Color.argb(35,255,255,255)); return g;
    }

    private void build(){
        FrameLayout root=new FrameLayout(this); root.setBackground(new AmbientDrawable());
        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(18),dp(62),dp(18),dp(18));
        root.addView(page,new FrameLayout.LayoutParams(-1,-1));

        TextView eyebrow=new TextView(this); eyebrow.setText("TODAY"); eyebrow.setTextColor(Color.argb(125,255,255,255)); eyebrow.setTextSize(11); eyebrow.setLetterSpacing(.18f);
        page.addView(eyebrow);
        TextView title=new TextView(this); title.setText("Сделать сегодня"); title.setTextColor(Color.WHITE); title.setTextSize(29); title.setTypeface(null,1); title.setPadding(0,dp(4),0,0); page.addView(title);

        LinearLayout meta=new LinearLayout(this); meta.setGravity(Gravity.CENTER_VERTICAL); meta.setPadding(0,dp(3),0,dp(14));
        TextView date=new TextView(this); date.setText(new SimpleDateFormat("d MMMM, EEEE",new Locale("ru")).format(new Date())); date.setTextColor(Color.argb(150,255,255,255)); date.setTextSize(12);
        counter=new TextView(this); counter.setTextColor(Color.argb(150,255,255,255)); counter.setTextSize(12); counter.setGravity(Gravity.END);
        meta.addView(date,new LinearLayout.LayoutParams(0,dp(30),1)); meta.addView(counter,new LinearLayout.LayoutParams(dp(100),dp(30)));
        page.addView(meta);

        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setOverScrollMode(View.OVER_SCROLL_NEVER); scroll.setVerticalScrollBarEnabled(false);
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(0,dp(2),0,dp(92)); scroll.addView(list,new ScrollView.LayoutParams(-1,-2));
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        TextView hint=new TextView(this); hint.setText("1× — в процессе   •   2× — готово   •   3× — удалить"); hint.setTextColor(Color.argb(85,255,255,255)); hint.setTextSize(10); hint.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(30),Gravity.BOTTOM); hp.setMargins(dp(20),0,dp(20),dp(72)); root.addView(hint,hp);

        TextView plus=new TextView(this); plus.setText("+"); plus.setTextColor(Color.WHITE); plus.setTextSize(30); plus.setGravity(Gravity.CENTER); plus.setBackground(glass(26,32)); plus.setElevation(dp(12));
        FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(58),dp(58),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL); pp.bottomMargin=dp(18); root.addView(plus,pp);
        plus.setOnClickListener(v->addTask(true));

        setContentView(root); render();
    }

    private void render(){
        list.removeAllViews();
        for(int i=0;i<tasks.size();i++) addRow(i);
        int done=0; for(Task t:tasks) if(t.state==2) done++;
        counter.setText(done+" / "+tasks.size());
        if(tasks.isEmpty()){
            TextView empty=new TextView(this); empty.setText("Нажми + и добавь первую задачу"); empty.setTextColor(Color.argb(95,255,255,255)); empty.setTextSize(13); empty.setGravity(Gravity.CENTER); empty.setPadding(0,dp(60),0,0); list.addView(empty,new LinearLayout.LayoutParams(-1,dp(150)));
        }
    }

    private void addRow(final int index){
        Task t=tasks.get(index);
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(12),0,dp(9),0); row.setBackground(glass(15,20)); row.setElevation(dp(2));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(48)); rp.setMargins(0,0,0,dp(6)); list.addView(row,rp);

        TextView num=new TextView(this); num.setText((index+1)+")"); num.setTextColor(Color.argb(110,255,255,255)); num.setTextSize(12); num.setGravity(Gravity.CENTER_VERTICAL); row.addView(num,new LinearLayout.LayoutParams(dp(28),-1));

        EditText edit=new EditText(this); edit.setText(t.text); edit.setHint("Новая задача"); edit.setHintTextColor(Color.argb(70,255,255,255)); edit.setTextColor(t.state==2?Color.argb(150,255,255,255):Color.WHITE); edit.setTextSize(13.5f); edit.setSingleLine(true); edit.setPadding(0,0,dp(6),0); edit.setBackgroundColor(Color.TRANSPARENT); edit.setSelectAllOnFocus(false);
        row.addView(edit,new LinearLayout.LayoutParams(0,-1,1));
        edit.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){ if(index<tasks.size()){tasks.get(index).text=s.toString();save();}} public void afterTextChanged(Editable e){}});
        edit.setOnEditorActionListener((v,id,event)->{ if(tasks.size()<MAX){addTask(true);} return true; });

        TextView state=new TextView(this); state.setGravity(Gravity.CENTER); state.setTextSize(15); styleState(state,t.state); row.addView(state,new LinearLayout.LayoutParams(dp(34),dp(34)));
        state.setOnClickListener(v->{
            if(index>=tasks.size())return; Task x=tasks.get(index);
            if(x.state<2){x.state++;save();render();}
            else { tasks.remove(index);save();render(); }
        });
    }

    private void styleState(TextView v,int state){
        GradientDrawable g=new GradientDrawable(); g.setShape(GradientDrawable.RECTANGLE); g.setCornerRadius(dp(10));
        if(state==0){g.setColor(Color.argb(20,255,255,255));g.setStroke(dp(1),Color.argb(65,255,255,255));v.setText("");}
        else if(state==1){g.setColor(Color.rgb(245,185,55));g.setStroke(0,0);v.setText("•");v.setTextColor(Color.rgb(35,27,10));}
        else {g.setColor(Color.rgb(72,210,116));g.setStroke(0,0);v.setText("✓");v.setTextColor(Color.rgb(7,39,18));v.setTypeface(null,1);}
        v.setBackground(g);
    }

    private void addTask(boolean focus){
        if(tasks.size()>=MAX){Toast.makeText(this,"Максимум 20 задач на сегодня",Toast.LENGTH_SHORT).show();return;}
        tasks.add(new Task("",0)); save(); render();
        if(focus){ list.post(()->{ View row=list.getChildAt(tasks.size()-1); if(row instanceof LinearLayout){View e=((LinearLayout)row).getChildAt(1);e.requestFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(e,InputMethodManager.SHOW_IMPLICIT);}}); }
    }

    private void resetIfNewDay(){
        String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()); String old=prefs.getString("date","");
        if(!today.equals(old)) prefs.edit().clear().putString("date",today).apply();
    }
    private void save(){
        StringBuilder sb=new StringBuilder(); for(Task t:tasks){String safe=t.text.replace("\\","\\\\").replace("\n"," ").replace("\t"," ").replace("|","\\p"); sb.append(t.state).append('|').append(safe).append('\n');}
        prefs.edit().putString("items",sb.toString()).apply();
    }
    private void load(){
        String raw=prefs.getString("items",""); if(raw.isEmpty())return;
        for(String line:raw.split("\n",-1)){if(line.isEmpty())continue;int p=line.indexOf('|');if(p<0)continue;try{int s=Integer.parseInt(line.substring(0,p));String tx=line.substring(p+1).replace("\\p","|").replace("\\\\","\\");tasks.add(new Task(tx,s));}catch(Exception ignored){}}
    }

    class AmbientDrawable extends Drawable {
        Paint p=new Paint(1);
        @Override public void draw(Canvas c){
            int w=getBounds().width(),h=getBounds().height();
            p.setShader(new LinearGradient(0,0,w,h,new int[]{Color.rgb(7,8,12),Color.rgb(18,20,28),Color.rgb(7,8,12)},null,Shader.TileMode.CLAMP));c.drawRect(getBounds(),p);p.setShader(null);
            p.setColor(Color.argb(55,70,105,255));c.drawCircle(w*.12f,h*.12f,w*.42f,p);
            p.setColor(Color.argb(40,255,145,70));c.drawCircle(w*.95f,h*.36f,w*.38f,p);
            p.setColor(Color.argb(25,150,85,255));c.drawCircle(w*.55f,h*.88f,w*.55f,p);
        }
        public void setAlpha(int a){} public void setColorFilter(android.graphics.ColorFilter f){} public int getOpacity(){return android.graphics.PixelFormat.OPAQUE;}
    }
}
