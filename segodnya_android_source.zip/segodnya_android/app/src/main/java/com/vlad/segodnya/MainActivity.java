package com.vlad.segodnya;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private FrameLayout root;
    private LinearLayout list, bottomNav;
    private TextView counter, addCount, title, subtitle;
    private View addBar;
    private final ArrayList<Task> tasks = new ArrayList<>();
    private final ArrayList<HistoryItem> history = new ArrayList<>();
    private android.content.SharedPreferences prefs;
    private final int MAX = 20;
    private boolean historyMode = false;

    static class Task { String text; int state; Task(String t,int s){text=t;state=s;} }
    static class HistoryItem { String text; long completedAt; HistoryItem(String t,long c){text=t;completedAt=c;} }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.rgb(20,14,11));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if(Build.VERSION.SDK_INT>=30) getWindow().setDecorFitsSystemWindows(false);
        else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        prefs=getSharedPreferences("today",MODE_PRIVATE);
        resetIfNewDay(); load(); loadHistory(); build();
    }

    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable glass(float radius,int alpha){
        GradientDrawable g=new GradientDrawable(); g.setColor(Color.argb(alpha,255,248,240));
        g.setCornerRadius(dp(radius)); g.setStroke(dp(1),Color.argb(80,255,255,255)); return g;
    }
    private GradientDrawable solidRound(int color,float radius){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g;
    }
    private TextView text(String value,float sp,int color){
        TextView t=new TextView(this); t.setText(value); t.setTextSize(sp); t.setTextColor(color); return t;
    }

    private void build(){
        root=new FrameLayout(this);

        View wallpaper=new View(this);
        wallpaper.setBackground(new WarmWallpaperDrawable());
        root.addView(wallpaper,new FrameLayout.LayoutParams(-1,-1));

        View scrim=new View(this); scrim.setBackground(new ScrimDrawable());
        root.addView(scrim,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20),dp(62),dp(20),dp(154));
        root.addView(page,new FrameLayout.LayoutParams(-1,-1));

        TextView eyebrow=text("TODAY",11,Color.argb(190,255,255,255)); eyebrow.setLetterSpacing(.22f);
        page.addView(eyebrow);

        LinearLayout titleRow=new LinearLayout(this); titleRow.setGravity(Gravity.CENTER_VERTICAL); titleRow.setPadding(0,dp(4),0,0);
        title=text("Сделать сегодня",30,Color.WHITE); title.setTypeface(null,1);
        titleRow.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));
        TextView calendar=text("▦",24,Color.WHITE); calendar.setGravity(Gravity.CENTER); calendar.setBackground(glass(17,30));
        titleRow.addView(calendar,new LinearLayout.LayoutParams(dp(52),dp(52)));
        page.addView(titleRow);

        LinearLayout meta=new LinearLayout(this); meta.setGravity(Gravity.CENTER_VERTICAL);
        subtitle=text(formatToday(),12.5f,Color.argb(205,255,248,240));
        counter=text("",12.5f,Color.argb(205,255,248,240)); counter.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);
        meta.addView(subtitle,new LinearLayout.LayoutParams(0,dp(34),1));
        meta.addView(counter,new LinearLayout.LayoutParams(dp(90),dp(34)));
        page.addView(meta);

        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setOverScrollMode(View.OVER_SCROLL_NEVER); scroll.setVerticalScrollBarEnabled(false);
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(0,dp(6),0,dp(12));
        scroll.addView(list,new ScrollView.LayoutParams(-1,-2));
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        buildAddBar(); buildBottomNav();
        setContentView(root); render();
    }

    private String formatToday(){
        String s=new SimpleDateFormat("d MMMM, EEEE",new Locale("ru")).format(new Date());
        return s.length()>0?Character.toUpperCase(s.charAt(0))+s.substring(1):s;
    }

    private void buildAddBar(){
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(9),dp(6),dp(14),dp(6));
        bar.setBackground(glass(22,42)); bar.setElevation(dp(12));
        TextView plus=text("+",27,Color.rgb(111,75,54)); plus.setGravity(Gravity.CENTER); plus.setBackground(solidRound(Color.argb(225,255,246,235),50));
        bar.addView(plus,new LinearLayout.LayoutParams(dp(48),dp(48)));
        TextView label=text("Добавить задачу",14.5f,Color.WHITE); label.setPadding(dp(14),0,0,0);
        bar.addView(label,new LinearLayout.LayoutParams(0,-1,1));
        addCount=text("",12,Color.argb(200,255,248,240)); addCount.setGravity(Gravity.CENTER_VERTICAL|Gravity.END);
        bar.addView(addCount,new LinearLayout.LayoutParams(dp(58),-1));
        bar.setOnClickListener(v->addTask(true)); plus.setOnClickListener(v->addTask(true));
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-1,dp(64),Gravity.BOTTOM); p.setMargins(dp(20),0,dp(20),dp(88));
        root.addView(bar,p); addBar=bar;
    }

    private void buildBottomNav(){
        bottomNav=new LinearLayout(this); bottomNav.setOrientation(LinearLayout.HORIZONTAL); bottomNav.setPadding(dp(5),dp(5),dp(5),dp(5));
        bottomNav.setBackground(glass(31,50)); bottomNav.setElevation(dp(15));
        rebuildNav();
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-1,dp(72),Gravity.BOTTOM); p.setMargins(dp(20),0,dp(20),dp(10));
        root.addView(bottomNav,p);
    }

    private LinearLayout navItem(String icon,String label,boolean active){
        LinearLayout x=new LinearLayout(this); x.setOrientation(LinearLayout.VERTICAL); x.setGravity(Gravity.CENTER);
        if(active)x.setBackground(glass(27,56));
        TextView i=text(icon,22,active?Color.WHITE:Color.argb(145,255,255,255)); i.setGravity(Gravity.CENTER);
        TextView l=text(label,11.5f,active?Color.WHITE:Color.argb(145,255,255,255)); l.setGravity(Gravity.CENTER);
        x.addView(i,new LinearLayout.LayoutParams(-1,dp(31))); x.addView(l,new LinearLayout.LayoutParams(-1,dp(26)));
        return x;
    }

    private void rebuildNav(){
        if(bottomNav==null)return;
        bottomNav.removeAllViews();
        LinearLayout today=navItem("☷","Сегодня",!historyMode), hist=navItem("◷","История",historyMode);
        bottomNav.addView(today,new LinearLayout.LayoutParams(0,-1,1)); bottomNav.addView(hist,new LinearLayout.LayoutParams(0,-1,1));
        today.setOnClickListener(v->{hideKeyboard();historyMode=false;rebuildNav();render();});
        hist.setOnClickListener(v->{hideKeyboard();historyMode=true;rebuildNav();render();});
    }

    private void render(){
        list.removeAllViews();
        if(historyMode){
            title.setText("История"); subtitle.setText("Выполненные задачи"); counter.setText(String.valueOf(history.size()));
            addBar.setVisibility(View.GONE); renderHistory(); return;
        }
        title.setText("Сделать сегодня"); subtitle.setText(formatToday()); addBar.setVisibility(View.VISIBLE);
        for(int i=0;i<tasks.size();i++)addRow(i);
        int done=0; for(Task t:tasks)if(t.state==2)done++;
        counter.setText(done+" / "+tasks.size()); addCount.setText(tasks.size()+" / "+MAX);
        if(tasks.isEmpty()){
            LinearLayout empty=new LinearLayout(this); empty.setOrientation(LinearLayout.VERTICAL); empty.setGravity(Gravity.CENTER);
            TextView big=text("+",28,Color.WHITE); big.setGravity(Gravity.CENTER); big.setBackground(glass(26,38));
            empty.addView(big,new LinearLayout.LayoutParams(dp(52),dp(52)));
            TextView e=text("Добавь первую задачу на сегодня",13,Color.argb(190,255,255,255)); e.setGravity(Gravity.CENTER); e.setPadding(0,dp(14),0,0);
            empty.addView(e,new LinearLayout.LayoutParams(-1,dp(48))); list.addView(empty,new LinearLayout.LayoutParams(-1,dp(180)));
        }
    }

    private void addRow(final int index){
        Task t=tasks.get(index);
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(12),0,dp(8),0);
        row.setBackground(glass(16,34)); row.setElevation(dp(2));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(43)); rp.setMargins(0,0,0,dp(5)); list.addView(row,rp);

        TextView num=text((index+1)+")",11.5f,Color.argb(205,255,255,255)); num.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(num,new LinearLayout.LayoutParams(dp(31),-1));

        EditText edit=new EditText(this); edit.setText(t.text); edit.setHint("Новая задача");
        edit.setHintTextColor(Color.argb(130,255,255,255)); edit.setTextColor(t.state==2?Color.argb(190,255,255,255):Color.WHITE);
        edit.setTextSize(12.5f); edit.setSingleLine(true); edit.setPadding(0,0,dp(6),0); edit.setBackgroundColor(Color.TRANSPARENT);
        row.addView(edit,new LinearLayout.LayoutParams(0,-1,1));
        edit.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){if(index<tasks.size()){tasks.get(index).text=s.toString();save();}}
            public void afterTextChanged(Editable e){}
        });
        edit.setOnEditorActionListener((v,id,event)->{if(tasks.size()<MAX)addTask(true);return true;});

        TextView state=text("",15,Color.WHITE); state.setGravity(Gravity.CENTER); styleState(state,t.state);
        row.addView(state,new LinearLayout.LayoutParams(dp(31),dp(31)));
        state.setOnClickListener(v->{
            if(index>=tasks.size())return; Task x=tasks.get(index);
            if(x.state==0)x.state=1;
            else if(x.state==1){x.state=2;if(!x.text.trim().isEmpty())addHistory(x.text.trim());}
            else tasks.remove(index);
            save(); render();
        });
    }

    private void styleState(TextView v,int state){
        GradientDrawable g=new GradientDrawable(); g.setShape(GradientDrawable.RECTANGLE); g.setCornerRadius(dp(10));
        if(state==0){g.setColor(Color.argb(24,255,255,255));g.setStroke(dp(1),Color.argb(175,255,255,255));v.setText("");}
        else if(state==1){g.setColor(Color.rgb(250,193,70));g.setStroke(dp(1),Color.argb(150,255,230,160));v.setText("");}
        else{g.setColor(Color.rgb(79,190,111));g.setStroke(dp(1),Color.argb(130,180,255,200));v.setText("✓");v.setTextColor(Color.WHITE);v.setTypeface(null,1);}
        v.setBackground(g);
    }

    private void renderHistory(){
        if(history.isEmpty()){
            TextView empty=text("Здесь появятся выполненные задачи",13,Color.argb(190,255,255,255)); empty.setGravity(Gravity.CENTER);
            list.addView(empty,new LinearLayout.LayoutParams(-1,dp(180))); return;
        }
        String lastDay=""; SimpleDateFormat dayFmt=new SimpleDateFormat("d MMMM, EEEE",new Locale("ru")); SimpleDateFormat timeFmt=new SimpleDateFormat("HH:mm",Locale.getDefault());
        for(int i=history.size()-1;i>=0;i--){
            HistoryItem h=history.get(i); String day=dayFmt.format(new Date(h.completedAt));
            if(!day.equals(lastDay)){
                TextView d=text(day.toUpperCase(new Locale("ru")),10.5f,Color.argb(185,255,255,255)); d.setLetterSpacing(.12f); d.setPadding(dp(4),dp(12),0,dp(7));
                list.addView(d,new LinearLayout.LayoutParams(-1,dp(43))); lastDay=day;
            }
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(12),0,dp(12),0); row.setBackground(glass(16,31));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(48)); rp.setMargins(0,0,0,dp(6)); list.addView(row,rp);
            TextView check=text("✓",15,Color.WHITE); check.setGravity(Gravity.CENTER); check.setTypeface(null,1); check.setBackground(solidRound(Color.rgb(79,190,111),10));
            row.addView(check,new LinearLayout.LayoutParams(dp(29),dp(29)));
            TextView tx=text(h.text,12.5f,Color.WHITE); tx.setGravity(Gravity.CENTER_VERTICAL); tx.setPadding(dp(11),0,dp(8),0);
            row.addView(tx,new LinearLayout.LayoutParams(0,-1,1));
            TextView tm=text(timeFmt.format(new Date(h.completedAt)),10.5f,Color.argb(175,255,255,255)); tm.setGravity(Gravity.CENTER_VERTICAL|Gravity.END);
            row.addView(tm,new LinearLayout.LayoutParams(dp(48),-1));
        }
    }

    private void addHistory(String text){history.add(new HistoryItem(text,System.currentTimeMillis()));saveHistory();}

    private void addTask(boolean focus){
        if(tasks.size()>=MAX){Toast.makeText(this,"Максимум 20 задач на сегодня",Toast.LENGTH_SHORT).show();return;}
        historyMode=false; tasks.add(new Task("",0)); save(); rebuildNav(); render();
        if(focus)list.post(()->{View row=list.getChildAt(tasks.size()-1);if(row instanceof LinearLayout){View e=((LinearLayout)row).getChildAt(1);e.requestFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(e,InputMethodManager.SHOW_IMPLICIT);}});
    }

    private void hideKeyboard(){View v=getCurrentFocus();if(v!=null){((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(),0);v.clearFocus();}}

    private void resetIfNewDay(){
        String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()),old=prefs.getString("date","");
        if(!today.equals(old))prefs.edit().remove("items").putString("date",today).apply();
    }

    private String encode(String s){return android.util.Base64.encodeToString(s.getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);}
    private String decode(String s){try{return new String(android.util.Base64.decode(s,android.util.Base64.NO_WRAP),java.nio.charset.StandardCharsets.UTF_8);}catch(Exception e){return "";}}
    private void save(){StringBuilder sb=new StringBuilder();for(Task t:tasks)sb.append(t.state).append('|').append(encode(t.text)).append('\n');prefs.edit().putString("items",sb.toString()).apply();}
    private void load(){String raw=prefs.getString("items","");if(raw.isEmpty())return;for(String line:raw.split("\n",-1)){if(line.isEmpty())continue;int p=line.indexOf('|');if(p<0)continue;try{tasks.add(new Task(decode(line.substring(p+1)),Integer.parseInt(line.substring(0,p))));}catch(Exception ignored){}}}
    private void saveHistory(){StringBuilder sb=new StringBuilder();for(HistoryItem h:history)sb.append(h.completedAt).append('|').append(encode(h.text)).append('\n');prefs.edit().putString("history",sb.toString()).apply();}
    private void loadHistory(){String raw=prefs.getString("history","");if(raw.isEmpty())return;for(String line:raw.split("\n",-1)){if(line.isEmpty())continue;int p=line.indexOf('|');if(p<0)continue;try{history.add(new HistoryItem(decode(line.substring(p+1)),Long.parseLong(line.substring(0,p))));}catch(Exception ignored){}}}

    class WarmWallpaperDrawable extends Drawable{
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        Path path=new Path();
        @Override public void draw(Canvas c){
            Rect b=getBounds(); float w=b.width(),h=b.height();
            p.setShader(new LinearGradient(0,0,w,h,new int[]{Color.rgb(103,58,40),Color.rgb(199,139,104),Color.rgb(89,49,34)},null,Shader.TileMode.CLAMP));
            c.drawRect(b,p); p.setShader(null);
            // Large satin-like ribbons inspired by warm abstract phone wallpapers.
            path.reset(); path.moveTo(-w*.15f,-h*.02f); path.cubicTo(w*.45f,h*.02f,w*.52f,h*.22f,w*.12f,h*.36f); path.cubicTo(-w*.08f,h*.43f,-w*.10f,h*.56f,w*.28f,h*.67f); path.lineTo(w*.60f,h*.52f); path.cubicTo(w*.18f,h*.40f,w*.32f,h*.28f,w*.72f,h*.17f); path.cubicTo(w*.92f,h*.11f,w*.86f,h*.02f,w*.70f,-h*.05f); path.close();
            p.setShader(new LinearGradient(0,0,w*.7f,h*.6f,new int[]{Color.rgb(245,216,191),Color.rgb(177,113,79),Color.rgb(100,55,38)},null,Shader.TileMode.CLAMP)); c.drawPath(path,p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.2f)); p.setColor(Color.argb(170,255,239,220)); c.drawPath(path,p); p.setStyle(Paint.Style.FILL);
            path.reset(); path.moveTo(w*.95f,-h*.05f); path.cubicTo(w*.58f,h*.18f,w*.98f,h*.34f,w*.58f,h*.53f); path.cubicTo(w*.30f,h*.66f,w*.36f,h*.83f,w*.82f,h*1.05f); path.lineTo(w*1.15f,h*1.05f); path.lineTo(w*1.15f,-h*.05f); path.close();
            p.setShader(new LinearGradient(w*.45f,0,w,h,new int[]{Color.rgb(250,225,202),Color.rgb(190,126,92),Color.rgb(87,46,32)},null,Shader.TileMode.CLAMP)); c.drawPath(path,p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.1f)); p.setColor(Color.argb(145,255,244,228)); c.drawPath(path,p); p.setStyle(Paint.Style.FILL);
        }
        public void setAlpha(int a){} public void setColorFilter(android.graphics.ColorFilter f){} public int getOpacity(){return PixelFormat.OPAQUE;}
    }

    class ScrimDrawable extends Drawable{
        Paint p=new Paint(1);
        @Override public void draw(Canvas c){Rect b=getBounds();p.setShader(new LinearGradient(0,0,0,b.height(),new int[]{Color.argb(92,35,18,12),Color.argb(52,45,24,16),Color.argb(105,24,13,10)},null,Shader.TileMode.CLAMP));c.drawRect(b,p);p.setShader(null);}
        public void setAlpha(int a){} public void setColorFilter(android.graphics.ColorFilter f){} public int getOpacity(){return PixelFormat.TRANSLUCENT;}
    }
}
