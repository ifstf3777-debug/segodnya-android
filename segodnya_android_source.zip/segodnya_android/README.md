# Сегодня v3
Минималистичный Android todo на один день.

v3:
- чёрно-белый minimal UI
- 3 состояния задачи
- выполненные автоматически уходят вниз
- свайп влево: удалить + Undo
- свайп вправо: напоминание
- перенос незавершённых задач со вчера
- история по дням
- изменение порядка через удержание маркера ⋮⋮
- haptic feedback
- Android home-screen widget

## v3.1
- Fixed startup crash caused by incorrect progress-view lookup.
- Added null guard around progress indicator rendering.
