package com.vlad.segodnya;

import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.widget.*;
import java.util.*;

public class TodayWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids){for(int id:ids)update(c,m,id);}
    public static void updateAll(Context c){
        AppWidgetManager m=AppWidgetManager.getInstance(c);
        android.content.ComponentName n=new android.content.ComponentName(c,TodayWidget.class);
        int[] ids=m.getAppWidgetIds(n);for(int id:ids)update(c,m,id);
    }
    private static void update(Context c,AppWidgetManager m,int id){
        RemoteViews r=new RemoteViews(c.getPackageName(),R.layout.widget_today);
        android.content.SharedPreferences p=c.getSharedPreferences("today",Context.MODE_PRIVATE);
        String raw=p.getString("items","");
        ArrayList<String> lines=new ArrayList<>();int done=0,total=0;
        for(String line:raw.split("\n",-1)){
            if(line.isEmpty())continue;int x=line.indexOf('|');if(x<0)continue;
            try{
                int st=Integer.parseInt(line.substring(0,x));
                String txt=new String(android.util.Base64.decode(line.substring(x+1),android.util.Base64.NO_WRAP),java.nio.charset.StandardCharsets.UTF_8);
                total++;if(st==2)done++;
                if(st!=2&&!txt.trim().isEmpty()&&lines.size()<4)lines.add((st==1?"◐  ":"□  ")+txt.trim());
            }catch(Exception ignored){}
        }
        r.setTextViewText(R.id.w_count,done+" / "+total);
        int[] views={R.id.w1,R.id.w2,R.id.w3,R.id.w4};
        for(int i=0;i<4;i++){r.setTextViewText(views[i],i<lines.size()?lines.get(i):"");}
        Intent open=new Intent(c,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        r.setOnClickPendingIntent(R.id.widget_root,pi);
        m.updateAppWidget(id,r);
    }
}
