package com.vlad.segodnya;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private FrameLayout root;
    private LinearLayout list, nav, page;
    private TextView title, subtitle, progressText, addLabel;
    private View addButton;
    private final ArrayList<Task> tasks = new ArrayList<>();
    private final ArrayList<HistoryItem> history = new ArrayList<>();
    private android.content.SharedPreferences prefs;
    private boolean historyMode=false;
    private final int MAX=20;
    private Task deletedTask=null; private int deletedIndex=-1;
    private View undoBar;
    private Handler handler=new Handler(Looper.getMainLooper());
    private Runnable undoDismiss;
    private String todayKey;

    static class Task { String text; int state; Task(String t,int s){text=t;state=s;} }
    static class HistoryItem { String text; long at; HistoryItem(String t,long a){text=t;at=a;} }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if(Build.VERSION.SDK_INT>=30) getWindow().setDecorFitsSystemWindows(false);
        else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

        prefs=getSharedPreferences("today",MODE_PRIVATE);
        todayKey=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        loadHistory();
        loadTasksWithRollover();
        build();
        askRolloverIfNeeded();
        requestNotificationPermission();
    }

    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView tv(String s,float sp,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);return t;}
    private GradientDrawable round(int color,float r){
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;
    }
    private GradientDrawable stroke(int fill,int stroke,float r){
        GradientDrawable g=round(fill,r);g.setStroke(dp(1),stroke);return g;
    }

    private void build(){
        root=new FrameLayout(this);
        root.setBackground(new MinimalBackground());
        page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22),dp(64),dp(22),dp(112));
        root.addView(page,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles=new LinearLayout(this);titles.setOrientation(LinearLayout.VERTICAL);
        TextView eyebrow=tv("TODAY",10.5f,0xff777777);eyebrow.setLetterSpacing(.22f);
        title=tv("Сделать сегодня",28,Color.WHITE);title.setTypeface(null,1);title.setPadding(0,dp(5),0,0);
        titles.addView(eyebrow,new LinearLayout.LayoutParams(-1,dp(27)));
        titles.addView(title,new LinearLayout.LayoutParams(-1,dp(46)));
        top.addView(titles,new LinearLayout.LayoutParams(0,dp(76),1));
        progressText=tv("",12,0xffa8a8a8);progressText.setGravity(Gravity.CENTER);
        progressText.setBackground(stroke(0x12000000,0xff333333,17));
        top.addView(progressText,new LinearLayout.LayoutParams(dp(58),dp(38)));
        page.addView(top);

        subtitle=tv(formatDate(new Date()),12.5f,0xff8d8d8d);
        page.addView(subtitle,new LinearLayout.LayoutParams(-1,dp(35)));

        FrameLayout progressWrap=new FrameLayout(this);
        View rail=new View(this);rail.setBackground(round(0xff232323,2));
        progressWrap.addView(rail,new FrameLayout.LayoutParams(-1,dp(2),Gravity.CENTER_VERTICAL));
        View fill=new View(this);fill.setId(991);fill.setBackground(round(Color.WHITE,2));
        progressWrap.addView(fill,new FrameLayout.LayoutParams(0,dp(2),Gravity.CENTER_VERTICAL));
        page.addView(progressWrap,new LinearLayout.LayoutParams(-1,dp(16)));

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(0,dp(4),0,dp(72));
        scroll.addView(list,new ScrollView.LayoutParams(-1,-2));
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        buildAddButton();
        buildNav();
        buildUndo();
        setContentView(root);
        render();
    }

    private void buildAddButton(){
        LinearLayout b=new LinearLayout(this);b.setGravity(Gravity.CENTER);
        b.setBackground(stroke(0xfff3f3f3,0xffffffff,26));b.setElevation(dp(12));
        TextView plus=tv("+",27,Color.BLACK);plus.setGravity(Gravity.CENTER);plus.setTypeface(null,0);
        addLabel=tv("Новая задача",13.5f,Color.BLACK);addLabel.setGravity(Gravity.CENTER_VERTICAL);addLabel.setPadding(dp(8),0,dp(14),0);
        b.addView(plus,new LinearLayout.LayoutParams(dp(34),-1));b.addView(addLabel,new LinearLayout.LayoutParams(-2,-1));
        b.setOnClickListener(v->addTask());
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-2,dp(52),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);p.setMargins(0,0,0,dp(72));
        root.addView(b,p);addButton=b;
    }

    private void buildNav(){
        nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);nav.setPadding(dp(4),dp(4),dp(4),dp(4));
        nav.setBackground(stroke(0xee101010,0xff2d2d2d,27));nav.setElevation(dp(10));
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-1,dp(58),Gravity.BOTTOM);p.setMargins(dp(22),0,dp(22),dp(8));
        root.addView(nav,p);refreshNav();
    }

    private LinearLayout navItem(String icon,String label,boolean active){
        LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER);
        if(active)x.setBackground(round(0xfff2f2f2,23));
        TextView i=tv(icon,16,active?Color.BLACK:0xff777777);i.setGravity(Gravity.CENTER);
        TextView l=tv(label,12.5f,active?Color.BLACK:0xff777777);l.setGravity(Gravity.CENTER);l.setPadding(dp(7),0,0,0);
        x.addView(i,new LinearLayout.LayoutParams(dp(25),-1));x.addView(l,new LinearLayout.LayoutParams(-2,-1));return x;
    }

    private void refreshNav(){
        nav.removeAllViews();
        LinearLayout a=navItem("≡","Сегодня",!historyMode),b=navItem("◷","История",historyMode);
        nav.addView(a,new LinearLayout.LayoutParams(0,-1,1));nav.addView(b,new LinearLayout.LayoutParams(0,-1,1));
        a.setOnClickListener(v->{hideKeyboard();historyMode=false;refreshNav();render();});
        b.setOnClickListener(v->{hideKeyboard();historyMode=true;refreshNav();render();});
    }

    private void buildUndo(){
        TextView u=tv("Задача удалена     ОТМЕНИТЬ",12.5f,Color.WHITE);u.setGravity(Gravity.CENTER);
        u.setBackground(stroke(0xff1c1c1c,0xff393939,15));u.setVisibility(View.GONE);u.setElevation(dp(20));
        u.setOnClickListener(v->undoDelete());
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-1,dp(48),Gravity.BOTTOM);p.setMargins(dp(34),0,dp(34),dp(74));
        root.addView(u,p);undoBar=u;
    }

    private void render(){
        list.removeAllViews();
        View fill=((ViewGroup)page.getChildAt(2)).findViewById(991);
        if(historyMode){
            title.setText("История");subtitle.setText("Что уже сделано");progressText.setText(String.valueOf(history.size()));
            addButton.setVisibility(View.GONE);if(fill!=null){fill.getLayoutParams().width=0;fill.requestLayout();}renderHistory();return;
        }
        title.setText("Сделать сегодня");subtitle.setText(formatDate(new Date()));addButton.setVisibility(View.VISIBLE);
        int done=0;for(Task t:tasks)if(t.state==2)done++;
        progressText.setText(done+" / "+tasks.size());
        final int d=done,total=tasks.size();
        if(fill!=null)((ViewGroup)fill.getParent()).post(()->{
            int w=((View)fill.getParent()).getWidth();
            fill.getLayoutParams().width=total==0?0:(int)(w*(d/(float)total));fill.requestLayout();
        });
        for(int i=0;i<tasks.size();i++)addTaskRow(i);
        if(tasks.isEmpty()){
            TextView e=tv("На сегодня всё чисто.\nНажми + и добавь первое дело.",13,0xff6f6f6f);
            e.setGravity(Gravity.CENTER);e.setLineSpacing(dp(3),1);list.addView(e,new LinearLayout.LayoutParams(-1,dp(210)));
        }
    }

    private void addTaskRow(final int index){
        Task task=tasks.get(index);
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(2),0,dp(2),0);
        row.setTag(index);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(45));list.addView(row,rp);

        TextView handle=tv("⋮⋮",11,0xff4e4e4e);handle.setGravity(Gravity.CENTER);
        row.addView(handle,new LinearLayout.LayoutParams(dp(27),-1));

        TextView num=tv(String.format(Locale.US,"%02d",index+1),10.5f,0xff666666);num.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(num,new LinearLayout.LayoutParams(dp(31),-1));

        EditText edit=new EditText(this);edit.setText(task.text);edit.setHint("Новая задача");edit.setHintTextColor(0xff4f4f4f);
        edit.setTextColor(task.state==2?0xff777777:Color.WHITE);edit.setTextSize(12.8f);edit.setSingleLine(true);
        edit.setPadding(0,0,dp(8),0);edit.setBackgroundColor(Color.TRANSPARENT);
        if(task.state==2) edit.setPaintFlags(edit.getPaintFlags()|Paint.STRIKE_THRU_TEXT_FLAG);
        row.addView(edit,new LinearLayout.LayoutParams(0,-1,1));
        edit.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){if(index<tasks.size()){tasks.get(index).text=s.toString();saveTasks();updateWidget();}}
            public void afterTextChanged(Editable e){}
        });

        TextView state=tv("",15,Color.BLACK);state.setGravity(Gravity.CENTER);styleState(state,task.state);
        row.addView(state,new LinearLayout.LayoutParams(dp(27),dp(27)));
        state.setOnClickListener(v->cycleState(index));

        View divider=new View(this);divider.setBackgroundColor(0xff222222);
        list.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));

        // Swipe left = delete, swipe right = reminder. Long press handle = move mode.
        final float[] downX={0}, downY={0}; final long[] downAt={0};
        row.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){downX[0]=e.getRawX();downY[0]=e.getRawY();downAt[0]=System.currentTimeMillis();return false;}
            if(e.getAction()==MotionEvent.ACTION_UP){
                float dx=e.getRawX()-downX[0],dy=e.getRawY()-downY[0];
                if(Math.abs(dx)>dp(75)&&Math.abs(dx)>Math.abs(dy)*1.4f){
                    if(dx<0) deleteWithUndo(index); else showReminderMenu(index);
                    return true;
                }
            }
            return false;
        });
        handle.setOnLongClickListener(v->{showMoveDialog(index);return true;});
    }

    private void styleState(TextView v,int state){
        GradientDrawable g=new GradientDrawable();g.setCornerRadius(dp(7));
        if(state==0){g.setColor(Color.TRANSPARENT);g.setStroke(dp(1),0xff6f6f6f);v.setText("");}
        else if(state==1){g.setColor(0xff777777);g.setStroke(dp(1),0xff999999);v.setText("◐");v.setTextColor(Color.WHITE);v.setTextSize(13);}
        else{g.setColor(0xfff1f1f1);g.setStroke(dp(1),Color.WHITE);v.setText("✓");v.setTextColor(Color.BLACK);v.setTypeface(null,1);}
        v.setBackground(g);
    }

    private void cycleState(int index){
        if(index>=tasks.size())return;Task t=tasks.get(index);
        vibrate(t.state==1?35:18);
        if(t.state==0)t.state=1;
        else if(t.state==1){
            t.state=2;
            if(!t.text.trim().isEmpty())addHistory(t.text.trim());
            Task done=tasks.remove(index);tasks.add(done); // completed goes down
        } else t.state=0;
        saveTasks();updateWidget();render();
    }

    private void addTask(){
        if(tasks.size()>=MAX){Toast.makeText(this,"Максимум 20 дел",Toast.LENGTH_SHORT).show();return;}
        historyMode=false;tasks.add(new Task("",0));saveTasks();refreshNav();render();vibrate(12);
        list.post(()->{
            int child=(tasks.size()-1)*2;
            if(child<list.getChildCount()){
                View r=list.getChildAt(child);
                if(r instanceof LinearLayout){
                    View e=((LinearLayout)r).getChildAt(2);e.requestFocus();
                    ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(e,InputMethodManager.SHOW_IMPLICIT);
                }
            }
        });
    }

    private void deleteWithUndo(int index){
        if(index<0||index>=tasks.size())return;
        deletedIndex=index;deletedTask=tasks.remove(index);saveTasks();updateWidget();render();vibrate(20);
        undoBar.setVisibility(View.VISIBLE);
        if(undoDismiss!=null)handler.removeCallbacks(undoDismiss);
        undoDismiss=()->{undoBar.setVisibility(View.GONE);deletedTask=null;deletedIndex=-1;};
        handler.postDelayed(undoDismiss,4200);
    }
    private void undoDelete(){
        if(deletedTask!=null){
            tasks.add(Math.min(deletedIndex,tasks.size()),deletedTask);deletedTask=null;deletedIndex=-1;saveTasks();updateWidget();render();
        }
        undoBar.setVisibility(View.GONE);
    }

    private void showMoveDialog(int index){
        if(tasks.size()<2)return;
        String[] choices=new String[tasks.size()];
        for(int i=0;i<choices.length;i++)choices[i]="Позиция "+(i+1);
        new AlertDialog.Builder(this).setTitle("Переместить задачу").setItems(choices,(d,which)->{
            if(which==index)return;Task t=tasks.remove(index);tasks.add(Math.min(which,tasks.size()),t);saveTasks();updateWidget();render();vibrate(18);
        }).show();
    }

    private void showReminderMenu(int index){
        if(index<0||index>=tasks.size())return;
        String name=tasks.get(index).text.trim();if(name.isEmpty())name="Задача";
        final String taskName=name;
        String[] opts={"Через 30 минут","Через 1 час","Сегодня в 18:00"};
        new AlertDialog.Builder(this).setTitle("Напомнить").setItems(opts,(d,w)->{
            long when=System.currentTimeMillis();
            if(w==0)when+=30*60*1000L; else if(w==1)when+=60*60*1000L; else{
                Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,18);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);
                if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_MONTH,1);when=c.getTimeInMillis();
            }
            ReminderReceiver.schedule(this,taskName,when);
            Toast.makeText(this,"Напоминание установлено",Toast.LENGTH_SHORT).show();
        }).show();
    }

    private void renderHistory(){
        if(history.isEmpty()){
            TextView e=tv("Здесь появятся выполненные задачи.",13,0xff666666);e.setGravity(Gravity.CENTER);
            list.addView(e,new LinearLayout.LayoutParams(-1,dp(190)));return;
        }
        LinkedHashMap<String,ArrayList<HistoryItem>> groups=new LinkedHashMap<>();
        SimpleDateFormat keyFmt=new SimpleDateFormat("yyyy-MM-dd",Locale.US);
        for(int i=history.size()-1;i>=0;i--){
            HistoryItem h=history.get(i);String k=keyFmt.format(new Date(h.at));
            if(!groups.containsKey(k))groups.put(k,new ArrayList<>());groups.get(k).add(h);
        }
        SimpleDateFormat dayFmt=new SimpleDateFormat("d MMMM, EEEE",new Locale("ru"));
        SimpleDateFormat timeFmt=new SimpleDateFormat("HH:mm",Locale.getDefault());
        int shown=0;
        for(Map.Entry<String,ArrayList<HistoryItem>> en:groups.entrySet()){
            if(shown++>13)break;
            Date day;try{day=keyFmt.parse(en.getKey());}catch(Exception e){day=new Date();}
            ArrayList<HistoryItem> arr=en.getValue();
            LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(2),dp(11),0,dp(5));
            TextView d=tv(dayFmt.format(day).toUpperCase(new Locale("ru")),10,0xff777777);d.setLetterSpacing(.12f);
            TextView c=tv(arr.size()+" выполнено",10.5f,0xff777777);c.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);
            header.addView(d,new LinearLayout.LayoutParams(0,dp(31),1));header.addView(c,new LinearLayout.LayoutParams(dp(100),dp(31)));
            list.addView(header);
            for(HistoryItem h:arr){
                LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
                TextView check=tv("✓",13,Color.BLACK);check.setTypeface(null,1);check.setGravity(Gravity.CENTER);check.setBackground(round(0xffeeeeee,7));
                row.addView(check,new LinearLayout.LayoutParams(dp(25),dp(25)));
                TextView tx=tv(h.text,12.5f,0xffdddddd);tx.setPadding(dp(12),0,dp(6),0);tx.setGravity(Gravity.CENTER_VERTICAL);
                row.addView(tx,new LinearLayout.LayoutParams(0,dp(43),1));
                TextView tm=tv(timeFmt.format(new Date(h.at)),10.5f,0xff666666);tm.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);
                row.addView(tm,new LinearLayout.LayoutParams(dp(50),dp(43)));
                list.addView(row);
                View div=new View(this);div.setBackgroundColor(0xff202020);list.addView(div,new LinearLayout.LayoutParams(-1,dp(1)));
            }
        }
    }

    private void loadTasksWithRollover(){
        String oldDate=prefs.getString("date","");
        loadTasks();
        if(oldDate.isEmpty()){prefs.edit().putString("date",todayKey).apply();return;}
        if(!oldDate.equals(todayKey)){
            ArrayList<Task> pending=new ArrayList<>();
            for(Task t:tasks)if(t.state!=2&&!t.text.trim().isEmpty())pending.add(new Task(t.text,t.state));
            StringBuilder sb=new StringBuilder();for(Task t:pending)sb.append(t.state).append('|').append(enc(t.text)).append('\n');
            prefs.edit().putString("rollover",sb.toString()).putString("date",todayKey).putString("items","").apply();
            tasks.clear();
        }
    }

    private void askRolloverIfNeeded(){
        String raw=prefs.getString("rollover","");
        if(raw.isEmpty())return;
        ArrayList<Task> old=parseTasks(raw);
        if(old.isEmpty()){prefs.edit().remove("rollover").apply();return;}
        new AlertDialog.Builder(this)
            .setTitle("Со вчера осталось "+old.size())
            .setMessage("Перенести незавершённые задачи на сегодня?")
            .setNegativeButton("Удалить",(d,w)->prefs.edit().remove("rollover").apply())
            .setPositiveButton("Перенести",(d,w)->{
                for(Task t:old)if(tasks.size()<MAX)tasks.add(new Task(t.text,0));
                prefs.edit().remove("rollover").apply();saveTasks();updateWidget();render();
            }).show();
    }

    private void addHistory(String s){history.add(new HistoryItem(s,System.currentTimeMillis()));saveHistory();}
    private String formatDate(Date d){return new SimpleDateFormat("d MMMM · EEEE",new Locale("ru")).format(d);}
    private String enc(String s){return android.util.Base64.encodeToString(s.getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);}
    private String dec(String s){try{return new String(android.util.Base64.decode(s,android.util.Base64.NO_WRAP),java.nio.charset.StandardCharsets.UTF_8);}catch(Exception e){return "";}}
    private ArrayList<Task> parseTasks(String raw){
        ArrayList<Task> out=new ArrayList<>();for(String line:raw.split("\n",-1)){if(line.isEmpty())continue;int p=line.indexOf('|');if(p<0)continue;try{out.add(new Task(dec(line.substring(p+1)),Integer.parseInt(line.substring(0,p))));}catch(Exception ignored){}}return out;
    }
    private void loadTasks(){tasks.clear();tasks.addAll(parseTasks(prefs.getString("items","")));}
    private void saveTasks(){StringBuilder sb=new StringBuilder();for(Task t:tasks)sb.append(t.state).append('|').append(enc(t.text)).append('\n');prefs.edit().putString("items",sb.toString()).apply();}
    private void loadHistory(){String raw=prefs.getString("history","");for(String line:raw.split("\n",-1)){if(line.isEmpty())continue;int p=line.indexOf('|');if(p<0)continue;try{history.add(new HistoryItem(dec(line.substring(p+1)),Long.parseLong(line.substring(0,p))));}catch(Exception ignored){}}}
    private void saveHistory(){StringBuilder sb=new StringBuilder();for(HistoryItem h:history)sb.append(h.at).append('|').append(enc(h.text)).append('\n');prefs.edit().putString("history",sb.toString()).apply();}
    private void hideKeyboard(){View v=getCurrentFocus();if(v!=null){((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(),0);v.clearFocus();}}
    private void vibrate(long ms){android.os.Vibrator v=(android.os.Vibrator)getSystemService(VIBRATOR_SERVICE);if(v!=null){if(Build.VERSION.SDK_INT>=26)v.vibrate(android.os.VibrationEffect.createOneShot(ms,80));else v.vibrate(ms);}}
    private void updateWidget(){TodayWidget.updateAll(this);}
    private void requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},77);}

    class MinimalBackground extends Drawable{
        Paint p=new Paint(1);
        public void draw(Canvas c){
            Rect b=getBounds();c.drawColor(0xff080808);
            p.setShader(new RadialGradient(b.width()*.18f,b.height()*.06f,b.width()*.72f,new int[]{0xff1b1b1b,0xff0d0d0d,0xff080808},null,Shader.TileMode.CLAMP));c.drawRect(b,p);p.setShader(null);
        }
        public void setAlpha(int a){}public void setColorFilter(android.graphics.ColorFilter f){}public int getOpacity(){return PixelFormat.OPAQUE;}
    }
}
